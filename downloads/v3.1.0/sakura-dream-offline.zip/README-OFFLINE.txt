樱梦浮岛 · 富士花境 / Sakura Dream — Floating Island 3.1

1. 解压完整 ZIP（不要直接在压缩软件里打开）。
2. 双击 index.html，用最新版 Windows Chrome 或 Edge 浏览器打开。
   单独下载的 sakura-dream-offline.html 也可直接打开。
3. 全部模型、材质、字体替代方案、Shader、脚本和源代码归档均已内嵌。
   不需要互联网、Node.js、Python、账号或付费服务。
4. 如浏览器不允许 file:// 页面，双击 start-local.cmd。
   它使用 Windows 内置 PowerShell，在随机空闲端口启动仅监听
   127.0.0.1 的本地服务，并打开默认浏览器。不修改系统执行策略。
   保留命令窗口，关闭窗口即可结束服务。无需管理员权限。
   如果组织策略禁止 PowerShell 或 WebGL，请联系设备管理员；启动器不会绕过策略。

操作：左键拖动旋转，滚轮缩放，右键拖动平移。
R 恢复英雄视角；H 隐藏/显示界面；空格播放/暂停昼夜；Esc 恢复界面。
正面、俯视、侧面及环绕按钮均可用。时间为 00:00—24:00，自动循环约四分钟。
晴、雨、雪独立于时间；雨雪强度可调。画质分低、中、高，并自动调整渲染分辨率。
页面内可再次下载独立 HTML、完整离线包及可编辑源码。

需要 WebGL 2 和浏览器硬件加速。虚拟机/远程桌面可能没有合适的图形能力。
本项目已在云端 Chromium 禁用所有网络后验证实际内嵌 HTML 和交互。
云端管理策略限制 file://，因此使用 about:blank 载入完全相同的 HTML 测试。
实际 Windows 双击和 Windows PowerShell 启动器仍需在 Windows 设备上验证。

原创程序化场景，MIT 许可；第三方许可证见 THIRD_PARTY_LICENSES.txt。
参考图仅用于构图与风格研究，没有将图片或游戏专有资产打包到作品中。
